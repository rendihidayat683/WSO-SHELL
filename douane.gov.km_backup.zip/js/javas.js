var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
$(document).ready(function(){
	$("#click-me").click(function(){
	   	 $("#intro").show();
	});

	$(".badmin").click(function(){
	   	 $(".adminlogin").show();
	   	 $(".studentlogin").hide();
	   	 $(".teacherlogin").hide();
	   	 $(".parentlogin").hide();
	   	 $(".stafflogin").hide();
	});

	$(".bstudent").click(function(){
	   	 $(".adminlogin").hide();
	   	 $(".studentlogin").show();
	   	 $(".teacherlogin").hide();
	   	 $(".parentlogin").hide();
	   	 $(".stafflogin").hide();
	});

	$(".bteacher").click(function(){
	   	 $(".adminlogin").hide();
	   	 $(".studentlogin").hide();
	   	 $(".teacherlogin").show();
	   	 $(".parentlogin").hide();
	   	 $(".stafflogin").hide();
	});
	
	$(".bstaff").click(function(){
	   	 $(".adminlogin").hide();
	   	 $(".stafflogin").show();
	   	 $(".teacherlogin").hide();
	   	 $(".studentlogin").hide();
	   	 $(".parentlogin").hide();
	});

	$(".bparent").click(function(){
	   	 $(".adminlogin").hide();
	   	 $(".studentlogin").hide();
	   	 $(".parentlogin").show();
	   	 $(".stafflogin").hide();
	   	 $(".teacherlogin").hide();
	});
});



var b1 = document.getElementById("bteacher");
var b2 = document.getElementById("bstudent");
var b2 = document.getElementById("badmin");


}